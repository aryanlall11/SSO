<?php

require "vendor/autoload.php";

use Auth0\SDK\Auth0;

$auth0 = new Auth0([
  'domain' => 'aryan11.us.auth0.com',
  'client_id' => '40SHsdaufslnlQY6eI4Kzb7qVaUmEPat',
  'client_secret' => 'dG4KPrpY8GZKktKh_Tk-b9P6T1tjLISxOK7gA-ShjQYOQ_iGRmLCQVe567ZqkP4S',
  'redirect_uri' => 'http://www.service2.com/callback.php',
  'audience' => 'https://aryan11.us.auth0.com/userinfo',
  'persist_id_token' => true,
  'persist_access_token' => true,
  'persist_refresh_token' => true,
]);