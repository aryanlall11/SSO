<?php

require "vendor/autoload.php";

use Auth0\SDK\Auth0;

$auth0 = new Auth0([
  'domain' => 'aryan11.us.auth0.com',
  'client_id' => '4xoswvIjjAaHu4J7UWabidMRFUHGYhsF',
  'client_secret' => 'KdNnq_XhVfouolOHIlE1DSxfyDjUfO7ePiz12tlPYzk7ed7rBSXbG-bIFbvB3ixW',
  'redirect_uri' => 'http://www.service1.com/callback.php',
  'audience' => 'https://aryan11.us.auth0.com/userinfo',
  'persist_id_token' => true,
  'persist_access_token' => true,
  'persist_refresh_token' => true,
]);