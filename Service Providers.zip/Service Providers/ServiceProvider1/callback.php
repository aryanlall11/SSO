<?php

require "init.php";

$userInfo = $auth0->getUser();

if (!$userInfo) {
    die("Error while logging you in. Please retry");
} else {
    #var_dump($userInfo);
    #printf( 'Hello %s!', htmlspecialchars( $userInfo['name'] ) );
    $name = htmlspecialchars( $userInfo['name'] );
    $uid = htmlspecialchars( $userInfo['sub'] );
    $picture = htmlspecialchars( $userInfo['picture'] );
}
?>

<html>  
   <head>
      <title>Home - SP1</title>
      <meta charset="UTF-8">
    <!-- jQUERY   -->
    <script
      src="http://code.jquery.com/jquery-3.2.1.min.js"
      integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
      crossorigin="anonymous"></script>
    <!-- Auth0 -->
    <script src="https://cdn.auth0.com/js/auth0/8.8/auth0.min.js"></script>
    <!-- Bootstrap 4 -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.1.1.slim.min.js" integrity="sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js" integrity="sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/js/bootstrap.min.js" integrity="sha384-vBWWzlZJ8ea9aCX4pEW3rVHjgjt7zpkNpZk+02D9phzyeVkE+jo0ieGizqPLForn" crossorigin="anonymous"></script>
    

    <!-- Initializing Script -->
    <script>
        $(document).ready(function() {
          var webAuth = new auth0.WebAuth({
            domain: 'aryan11.us.auth0.com',
            clientID: '4xoswvIjjAaHu4J7UWabidMRFUHGYhsF',
            redirectUri: 'http://www.service1.com/callback.php',
            audience: 'https://aryan11.us.auth0.com/userinfo',
            responseType: 'code',
            scope: 'openid profile'
          });

          $('#login').click(function(e) {
            e.preventDefault();
            webAuth.authorize();
          });

          $('#logout').click(function(e) {
            e.preventDefault();
            webAuth.logout();
            alert("Logout Successful!");
          });
        });
    </script>
   </head>   
   <body>
      <div class="container" style="margin-top: 200px;">

        <center>
        <h2><font color="olive">User Details</font></h2>  
	    <table border="1" style="border-collapse: collapse" cellpadding="10">  
	    <tr>  
	      <td width="250" height="20" align="center" ><b><font size="5" color="red">User ID:</font></b></td>  
	      <td width="250" height="20" align="left" ><b><font size="5"><?=$uid?></font></b></td>  
	    </tr>  
	    <tr>  
	      <td width="250" height="20" align="center" ><b><font size="5" color="red">Name:</font></b></td>  
	      <td width="250" height="20" align="center" ><b><font size="5"><?=$name?></font></b></td>  
	    </tr>  
	    <tr>  
	      <td width="250" height="20" align="center" ><b><font size="5" color="red">Profile Picture:</font></b></td>  
	      <td width="250" height="20" align="center" ><img src= <?=$picture?> width=50></td>
	    </tr> 
	    </table>
	    </center> 
    </div>

    <div class="container" style="margin-top: 50px;">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <button id="logout" class="btn btn-lg btn-danger btn-block">Log Out</button>
            </div>
        </div>
    </div>
   </body>    
</html>  